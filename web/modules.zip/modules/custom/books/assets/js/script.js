// jQuery(document).ready(function($){
//     $( document ).ready(function() {
//         var googleAPI = "https://www.googleapis.com/books/v1/volumes?q=harry+potter";
//         // Make a ajax call to get the json data as response.
//         $.getJSON(googleAPI, function (response) {
//             var j = 0;
//             // Loop through all the items one-by-one
//             for (var i = 0; i < response.items.length; i++) {
//                 if(j==8){
//                   return;
//                 }
//                 // set the item from the response object
//                 var item = response.items[i];
        
//                 // Set the book title in the div
//                 console.log(item);
//                 j++;
//             }
//         });
//         $(".slectBookListLayout").click(function() {
//             var selectedOption = $('#slectBookListLayout').find(":selected").val();
//             if (selectedOption == 'list') {
//               $('.book-listing').addClass("list");
//             } else {
//               $('.book-listing').removeClass("list");
//             }
//         });
//     });
// });

const searchSubmit = document.getElementById('searchbutton');
searchSubmit.addEventListener('click', (e) => {
    e.preventDefault();
    var searchItem = document.getElementById('searchinput').value;
    console.log(searchItem);
    jQuery.ajax({
        url: "https://www.googleapis.com/books/v1/volumes?q=" + searchItem,
        dataType: "json",

        success: function(data) {
          console.log(data.items);
        },

        type: 'GET'
    });
});