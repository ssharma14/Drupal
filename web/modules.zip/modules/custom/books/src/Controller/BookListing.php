<?php
 
namespace Drupal\books\Controller;

use Drupal\Core\Controller\ControllerBase;
use Drupal\Core\TempStore\PrivateTempStoreFactory;
use Symfony\Component\DependencyInjection\ContainerInterface;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;


class BookListing extends ControllerBase {
 
  /**
   *   Method to render content/data to page
   */

  protected $tempStore;

  /**
   * Class constructor.
   */
  public function __construct(PrivateTempStoreFactory $tempStore) {
    $this->tempStore = $tempStore;
  }

  /**
   * {@inheritdoc}
   */
  public static function create(ContainerInterface $container) {
    return new static(
      $container->get('tempstore.private')
    );
  }

  /**
   * A location data processing.
   *
   * @param  Symfony\Component\HttpFoundation\Request $locationData
   * @return Symfony\Component\HttpFoundation\Response
   */
  public function processBooks(Request $request) {
    $locationData = json_decode($request->getContent());
    $this->tempStore->get('user_location')->set('location_data', $locationData);
    print_r($locationData);
    return new JsonResponse($locationData);
  }

  public function fetch(Request $request) {
    $locationData = $this->tempStore->get('user_location')->get('location_data');

    return new JsonResponse($locationData);
  }
  public function view() {
    return[
        '#theme' => 'book-listing',
        '#attached' => [
          'library' => [
              'books/general',
          ],
        ],
    ];
  }
 
}