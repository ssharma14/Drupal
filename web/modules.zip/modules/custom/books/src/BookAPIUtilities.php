<?php

namespace Drupal\books;

use Drupal\Core\Http\ClientFactory;
use Drupal\Core\Messenger\Messenger;
use GuzzleHttp\Exception\RequestException;

class BookAPIUtilities {

    private $client;
    private $messenger;

    public function __construct(ClientFactory $client, Messenger $messenger){
        $this->client = $client->fromOptions([
            'base_uri' => 'https://www.googleapis.com',
        ]);
        $this->messenger = $messenger;
    }

    public function getData($endpoint, $options = []){
        $data = [];
        try{
            $request = $this->client->get($endpoint, $options);
            $results = $request->getBody()->getContents();
            $data = json_decode($results);
        }
        catch(RequestException $e){
            //show any error
           $this->messenger->addError($e->getMessage());
        }
        return $data;
    }

    public function getBooks($search) {
        if (isset($_GET["search"])){
            $search = $_GET["search"];
        } else{
          $search = 'Adventures of Sherlock Holmes';
        }
        $options = ['query' => ['q' => $search]];
        $books = $this->getData('/books/v1/volumes', $options);
        return $books;
    }
}
